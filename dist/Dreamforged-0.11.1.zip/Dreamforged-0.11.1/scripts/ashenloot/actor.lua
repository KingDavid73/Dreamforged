local core = require('openmw.core')
local types = require('openmw.types')
local self = require('openmw.self')
local I = require('openmw.interfaces')
local C = require('scripts.ashenloot.config')
local storage = require('openmw.storage')
local nearby = require('openmw.nearby')
local animation = require('openmw.animation')
local hasRandomizer = core.contentFiles.has('morrowind_world_randomizer.omwscripts')
local randomizer = hasRandomizer and storage.globalSection('MWR_By_Diject')
local data = {checked = false, applied = false, deathSent = false, witnessed = false}
local timer, quiet, pendingAge = 0, 0, 0
local availabilityAt, availabilityValue = -math.huge, false
local followerAt, followerValue = -math.huge, false
local pending, deferred, lastBase = false, nil, nil
local function clearDenVfx()
    if not data.den or data.denVfxCleared then return end
    -- Den VFX are attached through the AddVfx event.  Keep a per-den id so
    -- removing one dead den cannot clear another den in the same cell.  The
    -- legacy id is also removed for saves created before ids were unique.
    local vfxId=data.denVfxId or ('dreamforged_den:'..self.id)
    animation.removeVfx(self,vfxId)
    core.sendGlobalEvent('RemoveVfx',vfxId)
    if not data.denVfxId then
        animation.removeVfx(self,'dreamforged_den')
        core.sendGlobalEvent('RemoveVfx','dreamforged_den')
    end
    data.denVfxCleared=true
end
local function isFollower()
    local now=core.getSimulationTime()
    if now-followerAt<1 then return followerValue end
    local follower = false
    I.AI.forEachPackage(function(package)
        if package.type == 'Follow' or package.type == 'Escort' then follower = true end
    end)
    followerAt,followerValue=now,follower
    return follower
end
local function invalidateAvailability()
    availabilityAt=-math.huge
    followerAt=-math.huge
end
local function available()
    local now=core.getSimulationTime()
    if now-availabilityAt<1 then return availabilityValue end
    local rec = self.type.record(self)
    if not C.unsafeContent then
        for _, offered in pairs(rec.servicesOffered or {}) do
            if offered then availabilityAt,availabilityValue=now,false;return false end
        end
    end
    if types.NPC.objectIsInstance(self) and not (C.npcProgression or (C.allowRespawningNPCs and rec.isRespawning)) then
        availabilityAt,availabilityValue=now,false;return false
    end
    availabilityValue=C.enabled and self.enabled and self.scale >= 0.001 and (C.unsafeContent or not isFollower())
        and (C.unsafeContent or not (C.protectQuestActors and
            (rec.isEssential or (rec.mwscript and (not types.Creature.objectIsInstance(self) or not rec.isRespawning)))))
    availabilityAt=now
    return availabilityValue
end
local function request(refresh)
    if not available() or (data.checked and not refresh) or pending then return end
    if quiet < C.settleSeconds then return end
    if randomizer and not randomizer:get('version') then return end
    pending = true
    pendingAge = 0
    core.sendGlobalEvent('AshenLoot_PrepareFighting', self)
    core.sendGlobalEvent('AshenLoot_Encounter', {actor = self})
end
I.Combat.addOnHitHandler(function(attack)
    if available() and attack.successful and attack.attacker and types.Player.objectIsInstance(attack.attacker) then
        data.witnessed = true
    end
end)
local function apply(event)
    data.checked = true
    if not event.elite then
        local spells=types.Actor.spells(self)
        if data.elite and data.elite.spellId and spells[data.elite.spellId] then spells:remove(data.elite.spellId) end
        if (data.modifierBonus or 0)>0 and not types.Actor.isDead(self) then
            local hp=types.Actor.stats.dynamic.health(self)
            hp.modifier=hp.modifier-data.modifierBonus
            hp.current=math.max(1,hp.current-data.modifierBonus)
        end
        data.elite=nil;data.modifierBonus=0;data.applied=false;data.delveHealthFraction=nil
        return
    end
    if types.Actor.isDead(self) then return end
    local oldSpell = data.elite and data.elite.spellId
    local spells = types.Actor.spells(self)
    -- Modifier abilities are separate from the tracked dynamic-health bonus.
    if not spells[event.elite.spellId] then spells:add(event.elite.spellId) end
    if oldSpell and oldSpell ~= event.elite.spellId and spells[oldSpell] then spells:remove(oldSpell) end
    if event.elite.healthModel == 2 then
        local hp = types.Actor.stats.dynamic.health(self)
        local delta = event.elite.healthBonus - (data.modifierBonus or 0)
        hp.modifier = hp.modifier + delta
        hp.current = math.max(1, hp.current + delta*(data.delveHealthFraction or 1))
        data.modifierBonus = event.elite.healthBonus
    end
    data.elite = event.elite
    data.delveHealthFraction=nil
    data.applied = true
    core.sendGlobalEvent('AshenLoot_Promoted', self)
end
local function result(event)
    pending = false
    deferred = event
end
local function disturbed()
    quiet = 0
end
local function update(dt)
    if dt <= 0 then return end
    timer = timer + dt
    quiet = quiet + dt
    if pending then
        pendingAge = pendingAge + dt
        if pendingAge > C.settleSeconds + 3 then pending = false end
    end
    -- Actor scripts are attached to every eligible active creature/NPC.  A
    -- one-second cadence is sufficient for promotion and boss-wave work while
    -- avoiding a per-quarter-second Lua allocation/update storm in populated
    -- exterior cells.
    if timer < 1 then return end
    timer = 0
    -- Some engine versions mark a corpse disabled before the normal
    -- availability check.  Clean up den visuals first so the effect never
    -- survives the spawner's death.
    if types.Actor.isDead(self) then clearDenVfx() end
    if not available() then return end
    if data.den then
        I.AI.removePackages()
        types.Actor.stats.ai.fight(self).base=0
    end
    local hp = types.Actor.stats.dynamic.health(self)
    if lastBase and hp.base ~= lastBase then quiet = 0 end
    lastBase = hp.base
    if types.Actor.isDead(self) then
        clearDenVfx()
        -- A fast kill still earns ordinary loot; never promote a corpse or a disabled parent.
        if (data.checked or data.witnessed) and not data.deathSent then
            data.deathSent = true
            core.sendGlobalEvent('AshenLoot_Death', self)
        end
        return
    end
    local fightingPlayer=false
    I.AI.forEachPackage(function(package)
        if package.type == 'Combat' and package.target and types.Player.objectIsInstance(package.target) then
            data.witnessed = true
            fightingPlayer=true
        end
    end)
    if quiet < C.settleSeconds then return end
    if deferred then
        local event = deferred
        deferred = nil
        if event.elite and event.elite.healthModel == 2 and event.elite.healthReference ~= hp.base then request(true)
        else apply(event) end
    end
    if data.applied then
        if data.elite.worldBoss and fightingPlayer then
            local now=core.getSimulationTime()
            local intensity=C.directorIntensity
            local firstDelay=20/intensity
            local repeatDelay=math.max(5,30/intensity)
            data.bossWaveAt=data.bossWaveAt or (now+firstDelay)
            if now>=data.bossWaveAt then
                data.bossWaveAt=now+repeatDelay
                core.sendGlobalEvent('AshenLoot_BossWave',self)
            end
        end
        if data.elite.healthModel == 2 and data.elite.healthReference ~= hp.base then request(true) end
        return
    end
    if data.checked or pending then return end
    if data.witnessed then request() end
end
return {
    interfaceName = 'AshenLootActor',
    interface = {version = 2, getStatus = function()
        return {quiet = quiet, pending = pending, checked = data.checked, applied = data.applied,
            witnessed = data.witnessed, available = available(), health = types.Actor.stats.dynamic.health(self).base,
            current = types.Actor.stats.dynamic.health(self).current, dead = types.Actor.isDead(self)}
    end},
    engineHandlers = {
        onActive = function() quiet, lastBase, pending, deferred = 0, nil, false, nil;invalidateAvailability() end,
        onUpdate = update,
        onSave = function() return data end,
        onLoad = function(saved) data = saved or data; pending = false; quiet = 0; lastBase = nil;invalidateAvailability() end,
    },
    eventHandlers = {
        AshenLoot_Consider = function()
            -- A den is a director object, not an encounter target.  It must
            -- remain a quiet spawn anchor and never consume a promotion roll.
            if data.den then return end
            if available() and not types.Actor.isDead(self) then
                local active=I.AI.getActivePackage()
                core.sendGlobalEvent(active and active.type=='Combat' and 'AshenLoot_PrepareFighting' or 'AshenLoot_Prepare',self)
            end
        end,
        AshenLoot_Scale = function(event)
            if data.scaled or not available() then return end
            data.scaled = true
            local hp = types.Actor.stats.dynamic.health(self)
            local fraction = hp.base > 0 and math.min(1,hp.current/hp.base) or 1
            local native = math.max(1,event.nativeLevel or types.Actor.stats.level(self).current)
            local delta = event.progression and event.level-native or 0
            -- Level growth scales with the creature's native durability, while the
            -- ratio path also makes high-tier loaded creatures usable at low level.
            local scaledHealth=hp.base
            if event.allowDownscale and delta<0 then
                local ratio=math.max(0.20,((event.level+4)/(native+4))^0.85)
                scaledHealth=hp.base*ratio
                local magicka=types.Actor.stats.dynamic.magicka(self)
                local magickaFraction=magicka.base>0 and math.min(1,magicka.current/magicka.base) or 1
                magicka.base=math.max(0,magicka.base*math.max(0.2,(event.level+4)/(native+4)))
                magicka.current=magicka.base*magickaFraction
            elseif delta>0 then
                scaledHealth=hp.base+delta*(3+math.min(8,hp.base*0.08))
            end
            hp.base = math.max(5,scaledHealth*event.health)
            hp.current = hp.base*fraction
            local strength=types.Actor.stats.attributes.strength(self)
            local strengthScale=1
            if event.allowDownscale and delta<0 then
                strengthScale=math.max(0.30,((event.level+4)/(native+4))^0.65)
            end
            strength.base = math.max(1,math.min(10000,(strength.base*strengthScale+math.max(0,delta)*1.1)*event.damage))
            if event.progression then types.Actor.stats.level(self).current=event.level end
        end,
        AshenLoot_Equip = function(items)
            if not available() then return end
            local eq = types.Actor.getEquipment(self)
            for _,entry in ipairs(items) do eq[entry.slot]=entry.id end
            types.Actor.setEquipment(self,eq)
        end,
        AshenLoot_Spawned = function()
            types.Actor.stats.ai.fight(self).base=90
            local player=nearby.players[1]
            if player then I.AI.startPackage{type='Combat',target=player,cancelOther=true} end
        end,
        Dreamforged_DelveSpawned = function(event)
            types.Actor.stats.ai.fight(self).base=100
            types.Actor.stats.ai.flee(self).base=0
            if event and event.healthFraction then
                data.delveHealthFraction=event.healthFraction
                local hp=types.Actor.stats.dynamic.health(self)
                hp.current=math.max(1,hp.base*event.healthFraction)
            end
            core.sendGlobalEvent('AshenLoot_Prepare',self)
        end,
        AshenLoot_DenSpawned = function(event)
            data.den=true
            invalidateAvailability()
            data.denVfxId=(event and event.vfxId) or ('dreamforged_den:'..self.id)
            I.AI.removePackages()
            types.Actor.stats.ai.fight(self).base=0
            if event and event.model then
                self:sendEvent('AddVfx',{model=event.model,
                    options={particleTextureOverride=event.particle,loop=true,useAmbientLight=false,
                        vfxId=data.denVfxId}})
            end
        end,
        AshenLoot_MythicAttack=function(target)
            if target and target:isValid() then
                types.Actor.stats.ai.fight(self).base=100
                I.AI.startPackage{type='Combat',target=target,cancelOther=true}
            end
        end,
        AshenLoot_MythicFollow=function(target)
            if target and target:isValid() then
                types.Actor.stats.ai.fight(self).base=20
                I.AI.startPackage{type='Follow',target=target,cancelOther=true}
            end
        end,
        AshenLoot_EncounterResult = result,
        mwr_actor_setDynamicBaseStats = disturbed, mwr_actor_setDynamicStats = disturbed,
        mwr_actor_randomizeSpells = disturbed, mwr_actor_randomizeInventory = disturbed,
        mwr_actor_setEquipment = disturbed,
    },
}
